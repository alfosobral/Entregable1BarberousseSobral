package Objects;

public record Pos(int r, int c) {}