package Objects;
public enum Booster {
    COIN,
    HEAL,
    POISON,
    NONE
}
